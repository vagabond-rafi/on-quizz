package userclasses;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.awt.Color;
import adminclasses.*;
//import adminclasses.*;
//import textfiles.*;
//import pictures.*;

public class Login implements ActionListener {
	private JFrame f;
	private JButton logb;
	private JButton regb;
	private JButton bb;
	
	private JLabel emaillab,imagelab;
	private JLabel passlab;
	private JPasswordField passtf;
	private JTextField emailtf;
	private String UserName;
	private String UserGender;
	private String UserPassword;
	private JCheckBox showHideCheckBox;
	
		//JFrame n=new JFrame("LOGIN HERE");
		//f=n;
		public Login()
	{
		f = new JFrame("LOGIN HERE");
		logb = new JButton();
		logb.setText("Login");
		regb = new JButton();
		regb.setText("Register");
		
		bb = new JButton();
		bb.setText("Back");
		
		emaillab = new JLabel("Email");
		passlab = new JLabel("Password");
		passtf = new JPasswordField();
		emailtf = new JTextField();
		imagelab = new JLabel();
		
		 showHideCheckBox = new JCheckBox("Show Password");
        showHideCheckBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (showHideCheckBox.isSelected()) {
                    passtf.setEchoChar((char) 0); // Show password
                } else {
                    passtf.setEchoChar('*'); // Hide password
                }
            }
        });
		
		//addActionListener
		logb.addActionListener(this);
		regb.addActionListener(this);
		bb.addActionListener(this);
		//add 
		f.add(logb);
		f.add(regb);
		f.add(bb);
		f.add(showHideCheckBox);
		f.add(emaillab);
		f.add(passlab);
		f.add(passtf);
		f.add(emailtf);
		f.add(imagelab);

		//setbound
		logb.setBounds(600,350,130,35);
		regb.setBounds(750,350,130,35);

		bb.setBounds(675,400,130,35);
		
		emaillab.setBounds(600,150,130,35);
		emailtf.setBounds(700,150,130,35);
		
		passlab.setBounds(600,230,130,35);
		passtf.setBounds(700,230,130,35);
		
	    showHideCheckBox.setBounds(800, 280, 130, 35);
		
		
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		f.setSize(1000,650);
		f.setLayout(null);
		//f.getContentPane().setBackground(new Color(135,106,135));
		//f.getContentPane().setBackground(new Color(255,255,153));
		//f.getContentPane().setBackground(new Color(204,204,204));
		f.getContentPane().setBackground(new Color(153,153,153));
		f.setVisible(true);
		f.setLocationRelativeTo(null);
		f.setResizable(false);
		
		  //icon setup
		 //ImageIcon icon = new ImageIcon("logicon5.png");
		 ImageIcon icon = new ImageIcon( "C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\pictures\\logicon5.png");
		
		 f.setIconImage(icon.getImage());
		//image setup
		//ImageIcon img = new ImageIcon("logicon.png");
		ImageIcon img = new ImageIcon("C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\pictures\\logicon.png");

		imagelab.setIcon(img);
		imagelab.setBounds(50,50,510,510);
		 
		
		
	}

	 public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton button = (JButton) e.getSource();
            if (button.getText().equals("Login")) {
                login();
            } else if (button.getText().equals("Register")) {
                f.dispose();
               new Registration();
            }
			else if (button.getText().equals("Back")) {
                f.dispose();
				new FrontPage();
            }
        }
    }
	private void login() {
        String email = emailtf.getText();
        String password = new String(passtf.getPassword());
        User user = null;
   
		ImageIcon icon11 = new ImageIcon("C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\pictures\\rightsign.png");
    if (email.equals("pulock@gmail.com") && password.equals("pulock")) {
		
           // JOptionPane.showMessageDialog(null,"Question added successfully."," ",JOptionPane.PLAIN_MESSAGE,icon1);
		   
            JOptionPane.showMessageDialog(f, "Admin Login Successful!"," ",JOptionPane.PLAIN_MESSAGE,icon11);
            f.dispose();
            new AdminDashboard();
            return;
         }
    else if (email.equals("a") && password.equals("a")) {
		// ImageIcon icon22 = new ImageIcon("rightsign.png");
            JOptionPane.showMessageDialog(f, "Admin Login Successful!"," ",JOptionPane.PLAIN_MESSAGE,icon11);
            f.dispose();
            new AdminDashboard();
            return;
         }


        try {
            File file = new File("userdata.txt");
            if (!file.exists()) {
                JOptionPane.showMessageDialog(f, "No user registered yet!"," ",JOptionPane.ERROR_MESSAGE);
                return;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            boolean loggedIn = false;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[1].equals(email) && parts[2].equals(password)) {
                    loggedIn = true;
                    user = new User(parts[0], parts[1], parts[2], parts[3]);
					UserName=user.getName();
					UserGender=user.getGender();
					UserPassword=user.getPassword();
			
                    break;
                }
            }
            reader.close();
          // ImageIcon icon1 = new ImageIcon("rightsign.png");
		   ImageIcon icon1 = new ImageIcon("C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\pictures\\rightsign.png");
            if (loggedIn) {
                JOptionPane.showMessageDialog(f,"Login Successful!"," ",JOptionPane.PLAIN_MESSAGE,icon1);
				
				//new Daashboard(emailtf.getText());
                f.dispose();
				new UserDashboard(emailtf.getText(),UserName,UserGender,UserPassword);
                //new Dashboard(user);
				
            } else {
                JOptionPane.showMessageDialog(f, "Invalid email or password!"," ",JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }





}
	
	

	
