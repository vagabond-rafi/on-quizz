

package adminclasses;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import java.io.File;//To hold file 
import javax.swing.filechooser.FileNameExtensionFilter;//To Filter Image files in file chooser
import java.awt.image.BufferedImage;//To Hold Image as Object
import javax.imageio.ImageIO;//To Read and Write Image
import java.io.IOException;
import userclasses.*;
//---------- Entity and Entity List Classes -----------


public class InventoryPage extends JFrame implements ActionListener, MouseListener {
	// Getting Screen Width and Hight
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	int width = (int) screenSize.getWidth();
	int height = (int) screenSize.getHeight();

	// Fonts to Apply in diffetent Components
	Font font30 = new Font("Cambria", Font.BOLD, 30);
	Font font25 = new Font("Cambria", Font.BOLD, 25);
	Font font20 = new Font("Cambria", Font.BOLD, 20);
	Font font15 = new Font("Cambria", Font.BOLD, 15);
	Font font12 = new Font("Cambria", Font.BOLD, 12);

	// Panels for Holding Componentes
	JPanel westPanel, centerPanel, eastPanel;

	// West Componentes
	JLabel idLabel, nameLabel, codeLabel, typeLabel, creditLabel, imageLabel;
	
	JTextField idTextField, nameTextField, codeTextField, typeTextField, creditTextField;
	
	JButton imageButton, addButton, updateButton;
	
	
	JComboBox comboBox;
	
	JFileChooser chooser;
	File file;
	BufferedImage img;
	String filExtension = "";
	
	
	// East Componentes
	JTextField searchTextField, deleteTextField;
	
	JButton searchButton, deleteButton, clearButton, showAllButton;

	// Center Componentes
	JScrollPane jsp;


	//Footer Components
	JButton backButton,saveButton;
	
	// Entity List
	CourseList courseList;

	public InventoryPage(CourseList courseList) {
		super("Inventory Page");
		// Initializ Frame
		initFrame();

		// Initializ EntityList to access Data
		this.courseList = courseList;

		// Initializ Title
		initTitle();

		// Initializ West, Center and East Panels
		initWestCenterEastPanels();
		
		// Initializ Footer
		initFooter(); 
		
		super.setVisible(true);
	}

	// *********************** Frame Initialization *****************************
	public void initFrame() {
		super.setDefaultCloseOperation(EXIT_ON_CLOSE);
		super.setSize(1000, 650);
		super.setLayout(new BorderLayout(0, 10));
		super.setExtendedState(JFrame.MAXIMIZED_BOTH);
	}

	// *********************** Title Initialization *****************************
	public void initTitle() {
		JLabel title = new JLabel("Tutorial Page");
		title.setOpaque(true);
		//title.setBackground(new Color(45, 149, 150));
		title.setBackground(new Color(216, 216, 216));
		
		title.setHorizontalAlignment(JLabel.CENTER);
		title.setVerticalAlignment(JLabel.CENTER);
		title.setFont(font25);
		super.add(title, BorderLayout.NORTH);
	}
	
	public void initFooter() {
		JLabel title = new JLabel("Please Select Your Courses Carefully!!");
		//title.setOpaque(true);
		//title.setBackground(new Color(216, 216, 216));
		title.setHorizontalAlignment(JLabel.CENTER);
		title.setVerticalAlignment(JLabel.CENTER);
		title.setFont(font20);
		
		backButton = createButton("<= Back");
		backButton.setBackground(new Color(0, 0, 0));
		backButton.setForeground(Color.WHITE);
		//backButton.setHorizontalAlignment(JButton.LEFT);

		saveButton = createButton("SAVE");
		saveButton.setBackground(new Color(0, 0, 0));
		saveButton.setForeground(Color.WHITE);
		//saveButton.setHorizontalAlignment(JButton.RIGHT);

		JPanel  footerPanel = new JPanel(new GridLayout(1,0,0,0));
		footerPanel.setBackground(new Color(216, 216, 216));
		footerPanel.add(backButton);
		//footerPanel.add(Box.createRigidArea(new Dimension(50, 0)));
		footerPanel.add(title);
		//footerPanel.add(Box.createRigidArea(new Dimension(50, 0)));
		footerPanel.add(saveButton);
		super.add(footerPanel, BorderLayout.SOUTH);
	}

	// **************** West Center and East Panels Initialization ******************
	public void initWestCenterEastPanels() {
		// West Panel Setup
		westPanel = new JPanel();
		westPanel.setLayout(new BoxLayout(westPanel, BoxLayout.PAGE_AXIS));
		westPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));
		 westPanel.setBackground(new Color(0, 0, 0));
		this.addWestComponents();
		super.add(westPanel, BorderLayout.WEST);

		// Center JScrollPane and centerPanel Setup
		this.addCenterComponents();
		super.add(jsp, BorderLayout.CENTER);
		

		// East Panel Setup
		eastPanel = new JPanel();
		eastPanel.setLayout(new BoxLayout(eastPanel, BoxLayout.PAGE_AXIS));
		eastPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));
		eastPanel.setBackground(new Color(0, 0, 0));
		addEastComponents();
		super.add(eastPanel, BorderLayout.EAST);
	}

	public JLabel createLabel(String text) {
		JLabel label = new JLabel(text);
		label.setFont(font15);
		// label.setBorder(BorderFactory.createEmptyBorder(0,10,0,10));
		// label.setMinimumSize(new Dimension(200,30));
		label.setPreferredSize(new Dimension(200, 30));
		label.setMaximumSize(new Dimension(200, 30));
		label.setAlignmentX(Component.LEFT_ALIGNMENT);
		label.setForeground(Color.WHITE);
		return label;
	}

	public JTextField createTextField() {
		JTextField textField = new JTextField();
		textField.setFont(font15);
		// textField.setBorder(BorderFactory.createLineBorder(Color.black));
		// textField.setMinimumSize(new Dimension(200,30));
		textField.setPreferredSize(new Dimension(250, 30));
		textField.setMaximumSize(new Dimension(250, 30));
		textField.setAlignmentX(Component.LEFT_ALIGNMENT);
		return textField;
	}

	public JButton createButton(String text) {
		JButton button = new JButton(text);
		button.setFont(font15);
		button.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
		// button.setMinimumSize(new Dimension(200,30));
		button.setPreferredSize(new Dimension(200, 30));
		button.setMaximumSize(new Dimension(Short.MAX_VALUE, Short.MAX_VALUE));
		button.setAlignmentX(Component.LEFT_ALIGNMENT);
		button.addActionListener(this);
		return button;
	}

	/*--------------------------------------------------------------
	-------------------- WEST PANEL COMPONENTS ---------------------
	----------------------------------------------------------------*/
	void addWestComponents() {
		// ============Course Entry Form ===========
		// ============Course ID Entry ===========
		idLabel = createLabel("Course ID");
		idTextField = createTextField();
		

		// ============Course Name Entry ===========
		nameLabel = createLabel("Course Name");
		nameTextField = createTextField();

		// ============Course Code Entry ===========
		codeLabel = createLabel("Course Code");
		codeTextField = createTextField();
		// ============Course Type Entry ===========

		typeLabel = createLabel("Course Type");
		String courseTypes[] = { "Computer Science", "Computer Engineering", "Mathematics", "Natural Science", "Language" };
		comboBox = new JComboBox(courseTypes);
		comboBox.setPreferredSize(new Dimension(200, 30));
		comboBox.setAlignmentX(LEFT_ALIGNMENT);
		typeTextField = createTextField();

		// ============Course Credit Entry ===========
		creditLabel = createLabel("Course Credit");
		creditTextField = createTextField();
		
		// ============Image Chooser Button ===========
		ImageIcon imageIcon = new ImageIcon(new ImageIcon("./Resources/default.png").getImage().getScaledInstance(100, 150, Image.SCALE_DEFAULT));
		imageLabel = createLabel("Image");
		imageLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
		imageButton = new JButton(imageIcon);
		imageButton.setBackground(Color.BLACK);
		imageButton.setOpaque(false);
		imageButton.addActionListener(this);

		// ============Course Entry Buttons===========
		addButton = createButton("ADD");
		addButton.setBackground(new Color(192, 192, 192));
		addButton.setForeground(Color.BLACK);

		updateButton = createButton("UPDATE");
		updateButton.setBackground(new Color(192, 192, 192));
		updateButton.setForeground(Color.BLACK);

		int gap = 5;
		// Adding to West Panel
		westPanel.add(idLabel);
		westPanel.add(idTextField);
		westPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Adjust the height as needed

		westPanel.add(nameLabel);
		westPanel.add(nameTextField);
		westPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Adjust the height as needed

		westPanel.add(codeLabel);
		westPanel.add(codeTextField);
		westPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Adjust the height as needed

		westPanel.add(typeLabel);
		westPanel.add(comboBox);
		westPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Adjust the height as needed

		westPanel.add(creditLabel);
		westPanel.add(creditTextField);
		westPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Adjust the height as needed

		//westPanel.add(imageLabel);
		westPanel.add(imageButton);
		westPanel.add(Box.createRigidArea(new Dimension(0, gap+20)));

		westPanel.add(addButton);
		westPanel.add(Box.createRigidArea(new Dimension(0, gap)));

		westPanel.add(updateButton);
		westPanel.add(Box.createRigidArea(new Dimension(0, gap)));
	}

	void addCenterComponents() {
		centerPanel = new JPanel();
		centerPanel.setBackground(new Color(0, 0, 0));
	
		reloadAllCourses();
		jsp = new JScrollPane(centerPanel);
		jsp.getVerticalScrollBar().setUnitIncrement(16);
	}

	void addEastComponents() {
		JLabel searchLabel = createLabel("Search By Course ID");
		searchTextField = createTextField();
		searchButton = createButton("SEARCH");
		searchButton.setBackground(new Color(192, 192, 192));
		searchButton.setForeground(Color.BLACK);

		// ============Course Delete Entry ===========
		JLabel deleteLabel = createLabel("Delete By Course ID");
		deleteTextField = createTextField();

		deleteButton = createButton("DELETE");
		deleteButton.setBackground(new Color(192, 192, 192));
		deleteButton.setForeground(Color.BLACK);

		// ============ Get All Course Button =============
		showAllButton = createButton("SHOW ALL COURSES");
		showAllButton.setBackground(new Color(192, 192, 192));
		showAllButton.setForeground(Color.BLACK);

		// ============ Clear Button =============
		clearButton = createButton("CLEAR SCREEN");
		clearButton.setBackground(new Color(192, 192, 192));
		clearButton.setForeground(Color.BLACK);

		int gap = 20;

		eastPanel.add(searchLabel);
		eastPanel.add(searchTextField);
		eastPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Adjust the height as needed

		eastPanel.add(searchButton);
		eastPanel.add(Box.createRigidArea(new Dimension(0, gap)));

		eastPanel.add(deleteLabel);
		eastPanel.add(deleteTextField);
		eastPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Adjust the height as needed

		eastPanel.add(deleteButton);
		eastPanel.add(Box.createRigidArea(new Dimension(0, 200)));

		eastPanel.add(clearButton);
		eastPanel.add(Box.createRigidArea(new Dimension(0, gap)));

		eastPanel.add(showAllButton);
		eastPanel.add(Box.createRigidArea(new Dimension(0, gap)));
	}

	// ******************* COURSE TILE USING PANEL **********************
	public JPanel createCoursePanel(Course b) {

		JPanel coursePanel = new JPanel(new GridBagLayout());
		coursePanel.addMouseListener(this);
		coursePanel.setBackground(new Color(255, 255, 255));
		
		int coursePanelWidth  = 130;
		int coursePanelHeight = 250;
		coursePanel.setMinimumSize(new Dimension(coursePanelWidth, coursePanelHeight));
		coursePanel.setPreferredSize(new Dimension(coursePanelWidth, coursePanelHeight));
		coursePanel.setMaximumSize(new Dimension(coursePanelWidth, coursePanelHeight));
		coursePanel.setBorder(BorderFactory.createMatteBorder(5, 5, 5, 5, new Color(150, 150, 150)));

		// Loading image to label and resizing to fit in 130 X 186 pixel size
		JLabel imageLabel = new JLabel(new ImageIcon(new ImageIcon(b.getImage()).getImage().getScaledInstance(120, 160, Image.SCALE_DEFAULT)));
		imageLabel.setPreferredSize(new Dimension(100, 160));
		imageLabel.setMaximumSize(new Dimension(100, 160));

		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridwidth = 3; // 3 columns wide
		c.gridx = 0;
		c.gridy = 0;
		coursePanel.add(imageLabel, c);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.anchor = GridBagConstraints.PAGE_END;
		c.gridwidth = 3;

		c.gridx = 1;
		c.gridy = 1;

		JTextArea textArea = new JTextArea(0, 20);
		textArea.setFont(font12);
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setEditable(false);
		textArea.setOpaque(false);
		textArea.setText("ID:"+b.getCourseId()+"\n"+
						  b.getCourseName()+", "+
						  b.getCourseCode()+"\n"+
						  b.getCourseType()+"\n"+
						  "Remaining: "+b.getCourseCredit());
		
		coursePanel.add(textArea,c);
/*
		coursePanel.add(createLabel("ID:"+b.getCourseId()), c);
		
		c.gridy = 2;
		coursePanel.add(createLabel(b.getCourseName()), c);

		c.gridy = 3;
		coursePanel.add(createLabel(b.getCourseCode()), c);

		c.gridy = 4;
		coursePanel.add(createLabel(b.getCourseType()), c);

		c.gridy = 5;
		coursePanel.add(createLabel("Count: " + b.getCourseCredit()), c);
		*/
		return coursePanel;
	}

	public void reloadAllCourses() {
		centerPanel.removeAll();
		centerPanel.setLayout(new GridLayout(0, 5, 10, 10));

		Course courses[] = courseList.getAllCourses();
		for (int i = courses.length-1; i >= 0; i--) {
			if (courses[i] != null) {
				centerPanel.add(createCoursePanel(courses[i]));
			}
		}

		revalidate();
		repaint();
	}


	// ******************* Action Handling **********************
	@Override
	public void actionPerformed(ActionEvent e) {
		if (imageButton == e.getSource()) {
			try {
				FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG, GIF, and PNG Images", "jpg", "gif","png");
				chooser = new JFileChooser();
				chooser.setFileFilter(filter);
				chooser.showOpenDialog(this);
				file = chooser.getSelectedFile();
				img = ImageIO.read(file);

				ImageIcon icon = new ImageIcon(img); // Original
				ImageIcon imageIcon = new ImageIcon(icon.getImage().getScaledInstance(100, 150, Image.SCALE_DEFAULT));

				imageButton.setIcon(imageIcon);
				String extensions[] = { ".jpg", ".gif", ".png" };
				for (String extension : extensions) {
					if (file.getName().endsWith(extension)) {
						filExtension = extension;
						break;
					}
				}

				imageButton.revalidate();
				imageButton.repaint();
			} 
			catch (IOException e1) {
			} 
			catch (Exception e2) {
			}
		} 
		else if (addButton == e.getSource()) {
			System.out.println("Add Clicked");

			if (!idTextField.getText().isEmpty() &&
					!nameTextField.getText().isEmpty() &&
					!codeTextField.getText().isEmpty() &&
					!creditTextField.getText().isEmpty()) {
				Course b = courseList.getById(idTextField.getText());
				if (b == null) {
					String fileName = "";
					if (filExtension.isEmpty()) {
						fileName = "default.png";
					} else {
						fileName = idTextField.getText() + filExtension;
						try {
							ImageIO.write(img, "jpg", new File(".\\Resources\\" + fileName));
						} catch (IOException e1) {

						}
					}

					Course course = new Course(idTextField.getText(),
					nameTextField.getText(),
					codeTextField.getText(),
					comboBox.getItemAt(comboBox.getSelectedIndex()).toString(),
					Integer.parseInt(creditTextField.getText()),
					"./Resources/" + fileName);

					courseList.insert(course);
					CoursesFileIO.insertInFile(course.getCourseInfoAsString(), "courses.txt");
					reloadAllCourses();
				} else {
					JOptionPane.showMessageDialog(this, "ID already in Use, Enter a new Unique ID", "Error",
							JOptionPane.ERROR_MESSAGE);
				}
			} else {
				JOptionPane.showMessageDialog(this, "Enter All The Details", "Alert", JOptionPane.ERROR_MESSAGE);
			}
		} 
		else if (updateButton == e.getSource()) {
			System.out.println("Update Clicked");
			if (!idTextField.getText().isEmpty()) {
				Course b = courseList.getById(idTextField.getText());
				if (b != null) {
					if (!nameTextField.getText().isEmpty()) {
						b.setCourseName(nameTextField.getText());
					}

					if (!codeTextField.getText().isEmpty()) {
						b.setCourseCode(codeTextField.getText());
					}

					if (!comboBox.getItemAt(comboBox.getSelectedIndex()).toString().equals(b.getCourseType())) {
						b.setCourseType(comboBox.getItemAt(comboBox.getSelectedIndex()).toString());
					}

					if (!creditTextField.getText().isEmpty()) {
						b.setCourseCredit(Integer.parseInt(creditTextField.getText()));
					}
					reloadAllCourses();
				} else {
					JOptionPane.showMessageDialog(this, "No Available Course by This ID", "Course Not Found",
							JOptionPane.ERROR_MESSAGE);
				}
			} else {
				JOptionPane.showMessageDialog(this, "Please Provide ID for the Course", "Missing Information",
						JOptionPane.ERROR_MESSAGE);
			}

		} 
		else if (searchButton == e.getSource()) {
			System.out.println("Search Clicked");

			Course b = courseList.getById(searchTextField.getText());
			if (b != null) {
				// textArea.setText( b.getCourseInfoAsString() );

				centerPanel.removeAll();
				centerPanel.setLayout(new GridLayout(2, 1));
				centerPanel.add(createCoursePanel(b));
				revalidate();
				repaint();

			} else {
				// textArea.setText( "NO COURSE FOUND\n" );
				JOptionPane.showMessageDialog(this, "NO COURSE FOUND", "Alert", JOptionPane.WARNING_MESSAGE);
			}
		} 
		else if (deleteButton == e.getSource()) {
			System.out.println("Delete Clicked");
			courseList.deleteById(deleteTextField.getText());
			reloadAllCourses();
		} 
		else if (showAllButton == e.getSource()) {

			reloadAllCourses();
		} 
		else if (clearButton == e.getSource()) {
			centerPanel.removeAll();
			revalidate();
			repaint();
		}
		else if(saveButton == e.getSource()){
			CoursesFileIO.saveCoursesInFile(courseList);
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {

	}

	@Override
	public void mousePressed(MouseEvent e) {

	}

	@Override
	public void mouseReleased(MouseEvent e) {

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		if (e.getSource() instanceof JPanel)
			((JPanel) e.getSource()).setBackground(new Color(154, 208, 194));
	}

	@Override
	public void mouseExited(MouseEvent e) {
		if (e.getSource() instanceof JPanel )
			((JPanel) e.getSource()).setBackground(new Color(236, 244, 214));
	}
}
