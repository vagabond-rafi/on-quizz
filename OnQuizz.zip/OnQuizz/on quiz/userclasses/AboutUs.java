package userclasses;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import adminclasses.*;

public class AboutUs implements ActionListener {
	private JFrame frame ;
	private JButton bb;
	
	private JTextArea TextArea;
	
	
	 public AboutUs()
	{
		frame = new JFrame("ABOUT US ");
		
		
		TextArea = new JTextArea("This project was conducted by:" + "\n" + "\n" + "Pulock Kumar Kundu ,   ID:23-52481-2"+ "\n" + "\n" + "Md.Rafiul Islam,        ID:23-52452-2" + "\n" + "\n" + "Rayhan Rabby,         ID:23-52437-2" + "\n" + "\n" + "Md.Kais Rafat,          ID:23-52332-2"+"\n"+"\n" +"By the insight from:"+"\n"+"\n"+ "Md.Mazid-Hl-Haque ");
		TextArea.setFont(new Font("Arial",Font.BOLD,24));
		//add 
		frame.add(TextArea);
		bb = new JButton();
		bb.setText("Back");
		frame.add(bb);
		
		//setbound
		
		TextArea.setBounds(200,50,500,400);
		
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		frame.setSize(975,650);
		frame.setLayout(null);
		
		frame.getContentPane().setBackground(new Color(153,153,153));
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		
		bb.addActionListener(this);
		bb.setBounds(50,500,130,35);

		 
		
	}
	public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton button = (JButton) e.getSource();
			if (button.getText().equals("Back")) {
                frame.dispose();
				new FrontPage();
            }
        }
    }
	
	
	
}