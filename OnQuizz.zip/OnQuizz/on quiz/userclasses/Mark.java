package userclasses;
import java.lang.*;
import adminclasses.*;
public class Mark {
    private String name;
    private String email;
    private int count;
    private String gender;

    public Mark(String name, String email,String gender,int count) {
        this.name = name;
        this.email = email;
        this.gender = gender;
        this.count = count;
        
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
    public String getGender() {
        return gender;
    }
    public int getCount () {
        return count;
    }
   

    
}