package userclasses;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import adminclasses.*;

//import textfiles.*;
public class Quiz extends JFrame implements ActionListener {
	
    JLabel l;
    JRadioButton jb[] = new JRadioButton[5];
    JButton b1, b2, backButton;
    ButtonGroup bg;
    int count = 0, current = 0;
    JFrame f;
   
    String fileName;
    Question[] questions = new Question[10];
    JTextField questionNumberField; 
    private String name;
    private String email;

    private String gender;
    private String  UserPass;

	
	public Quiz(String s,String filen, String email, String name, String gender,String UserPass) {
		super(s);
		fileName = filen;
        this.name = name;
        this.email = email;
        this.gender = gender; 
        this.UserPass = UserPass;
       
        
        l = new JLabel();
        add(l);
        bg = new ButtonGroup();
        for (int i = 0; i < 5; i++) {
            jb[i] = new JRadioButton();
            add(jb[i]);
            bg.add(jb[i]);
        }
        b1 = new JButton("Next");
        b2 = new JButton(" ");
        backButton = new JButton("Back");
        b1.addActionListener(this);
       b2.addActionListener(this);
        backButton.addActionListener(this);
        add(b1);
        // add(b2);
        add(backButton);

        // Add question number field to the panel
       questionNumberField = new JTextField();
        add(new JLabel("Question Number: "));
        add(questionNumberField);

        loadQuestions(); // Load questions from file
        set(1); // Show the first question initially
        l.setBounds(30, 40, 450, 20);
        jb[0].setBounds(50, 80, 100, 20);
        jb[1].setBounds(50, 110, 100, 20);
        jb[2].setBounds(50, 140, 100, 20);
        jb[3].setBounds(50, 170, 100, 20);
        b1.setBounds(100, 240, 100, 30);
      backButton.setBounds(250,240,100,30);
        b2.setBounds(400, 240, 100, 30);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setLocation(250, 100);
        setVisible(true);
        setSize(600, 350);
        backButton.setEnabled(false); // Disable backButton initially
    }
  public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
           // selectedOption[current] = getSelectedIndex();
            if (check())
                count = count + 1;
            current++;
            backButton.setEnabled(true); // Enable backButton when moving forward
            set(current + 1);
            if (current == 9) {
                b1.setEnabled(false);
				add(b2);
                b2.setText("Result");
            }
        } else if (e.getSource() == backButton) {
            //selectedOption[current] = getSelectedIndex(); // Store selected option before moving back
            if (check())
                count = count + 1;
            current--;
            set(current + 1);
            backButton.setEnabled(current > 0);
            b1.setEnabled(true); // Enable Next button when moving back
            if (current == 9) {
                b1.setEnabled(false);
				add(b2);
                b2.setText("Result");
            }
			
        } 
       
        if (e.getActionCommand().equals("Result")) {
            //selectedOption[current] = getSelectedIndex();
            if (check())
                count = count + 1;
            current++;
            JOptionPane.showMessageDialog(this, "correct ans=" + count);
           // System.exit(0);

           Mark newMark = new Mark(name, email, gender,count);

           try {
               FileWriter writer = new FileWriter("marks.txt", true);
              
   
               writer.write(newMark.getName() + "," + newMark.getEmail() + "," + newMark.getGender() + "," + newMark.getCount() + "\n");
               writer.close();
               JOptionPane.showMessageDialog(f, "Mark Stored Successful!");
              // f.dispose();
              // new Login();
           } catch (IOException ex) {
               ex.printStackTrace();
           }

		   dispose();
			new UserQuizes(email,name,gender,UserPass);
           // JOptionPane.showMessageDialog(f, "Stored Successful!");
            

        }
    }
 void set(int questionNumber) {
    jb[4].setSelected(true);
    current = questionNumber - 1;

    if (current >= 0 && current < 10) { // Ensure current is within valid range
        // Find the question with the specified question number
        int index = -1;
        for (int i = 0; i < questions.length; i++) {
            if (Integer.parseInt(questions[i].getQuestionNumber()) == questionNumber) {
                index = i;
                break;
            }
        }
	
        if (index != -1) { // If question found
            l.setText("Que" + questions[index].getQuestionNumber() + ": " + questions[index].getQuestion()); // Display question
            for (int i = 0; i < 4; i++) { // Display options
                jb[i].setText(questions[index].getOptions()[i]);
            }
            
    }
   }
    l.setBounds(30, 40, 450, 20);
    for (int i = 0, j = 0; i <= 90; i += 30, j++){
        jb[j].setBounds(50, 80 + i, 200, 20);
          }
   }
   boolean check() {
        if (current >= 0 && current < 10) { // Ensure current is within valid range
           return (jb[Integer.parseInt(questions[current].getCorrectIndex())].isSelected());
            
        }
        return false;
    }


   void loadQuestions() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String line;
            int index = 0;
            while ((line = reader.readLine()) != null && index < 10) {
                String[] parts = line.split(",");
                if (parts.length == 7) { // Ensure each line has correct format
                    Question question = new Question(parts[0], parts[1], new String[]{parts[2], parts[3], parts[4], parts[5]}, parts[6]);
                    questions[index] = question;
                    index++;
                } 
				else {
                    System.out.println("Invalid question " + (index + 1));
                }
            }
            reader.close();
        } 
		catch (IOException e) {
            e.printStackTrace();
        }
    }
	/* public static void main(String[] args) {
        new Quiz();
    }*/
}