package userclasses;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
//import textfiles.*;
import adminclasses.*;
public class NewEdit implements ActionListener {
    private JFrame frame;
    private JTextField nameField, emailField;
    private JPasswordField passwordField;
    private JRadioButton maleRadioButton, femaleRadioButton, otherRadioButton;
    private JButton saveButton, cancelButton;
    private String originalEmail;
	private String Name;
	private String Email;
	private String Password;
	private String Gender;
 
    public NewEdit(String name, String email, String UserGender, String UserPass) {
		this.Name=name;
		this.Email=email;
		this.Gender=UserGender;
		this.Password=UserPass;
        frame = new JFrame("Edit Profile");
        frame.setSize(400, 300);
        frame.setLayout(null);
 
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(50, 30, 100, 30);
        frame.add(nameLabel);
        nameField = new JTextField(Name);
        nameField.setBounds(150, 30, 200, 30);
        frame.add(nameField);
 
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(50, 70, 100, 30);
        frame.add(emailLabel);
        emailField = new JTextField(Email);
        emailField.setBounds(150, 70, 200, 30);
        originalEmail = Email;
        frame.add(emailField);
 
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 110, 100, 30);
        frame.add(passwordLabel);
        passwordField = new JPasswordField(Password);
        passwordField.setBounds(150, 110, 200, 30);
        frame.add(passwordField);
 
        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setBounds(50, 150, 100, 30);
        frame.add(genderLabel);
 
        ButtonGroup genderGroup = new ButtonGroup();
        maleRadioButton = new JRadioButton("Male");
        maleRadioButton.setBounds(150, 150, 80, 30);
        maleRadioButton.setActionCommand("Male");
        femaleRadioButton = new JRadioButton("Female");
        femaleRadioButton.setBounds(240, 150, 80, 30);
        femaleRadioButton.setActionCommand("Female");
        otherRadioButton = new JRadioButton("Other");
        otherRadioButton.setBounds(330, 150, 80, 30);
        otherRadioButton.setActionCommand("Other");
 
        
        if (Gender.equals("Male")) {
            maleRadioButton.setSelected(true);
        } else if (Gender.equals("Female")) {
            femaleRadioButton.setSelected(true);
        } else {
            otherRadioButton.setSelected(true);
        }
 
        genderGroup.add(maleRadioButton);
        genderGroup.add(femaleRadioButton);
        genderGroup.add(otherRadioButton);
        frame.add(maleRadioButton);
        frame.add(femaleRadioButton);
        frame.add(otherRadioButton);
 
        saveButton = new JButton("Save");
        saveButton.setBounds(100, 200, 100, 30);
        saveButton.addActionListener(this);
        frame.add(saveButton);
 
        cancelButton = new JButton("Cancel");
        cancelButton.setBounds(220, 200, 100, 30);
        cancelButton.addActionListener(this);
        frame.add(cancelButton);
 
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
    }
 
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == saveButton) {
            String newName = nameField.getText();
            String newEmail = emailField.getText();
            String newPassword = new String(passwordField.getPassword());
            String newGender = "";
			
 
            
            if (maleRadioButton.isSelected()) {
                newGender = "Male";
            } else if (femaleRadioButton.isSelected()) {
                newGender = "Female";
            } else if (otherRadioButton.isSelected()) {
                newGender = "Other";
            }
 
            
            if (newName.isEmpty() || newEmail.isEmpty() || newPassword.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill all fields!");
                return;
            }
 
            
            if (!originalEmail.equals(newEmail) && isEmailExists(newEmail)) {
                JOptionPane.showMessageDialog(frame, "User with this email already exists!");
                return;
            }
 
            
            updateUserInfo(newName, newEmail, newPassword, newGender);
        } else if (e.getSource() == cancelButton) {
            frame.dispose();
        }
    }
 
    private boolean isEmailExists(String email) {
        try {
            File file = new File("userdata.txt");
            if (!file.exists()) {
                return false;
            }
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[1].equals(email)) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
    }
 
    private void updateUserInfo(String newName, String newEmail, String newPassword, String newGender) {
        try {
            File file = new File("userdata.txt");
            File tempFile = new File("temp.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
 
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[1].equals(originalEmail)) {
                    writer.write(newName + "," + newEmail + "," + newPassword + "," + newGender + "\n");
                } else {
                    writer.write(line + "\n");
                }
            }
            reader.close();
            writer.close();
 
            boolean deleteSuccess = file.delete();
            if (!deleteSuccess) {
                System.out.println("Could not delete the original file.");
                return;
            }
 
            boolean renameSuccess = tempFile.renameTo(file);
            if (!renameSuccess) {
                System.out.println("Could not rename the temp file.");
                return;
            }
 
            JOptionPane.showMessageDialog(frame, "Profile updated successfully!");
            frame.dispose();
			new Profile( newName,  newEmail, newPassword,  newGender);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
 
    
}