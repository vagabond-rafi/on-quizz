package userclasses;

import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.event.*;  
//import pictures;
import adminclasses.*;
public class FrontPage implements ActionListener {
	private JFrame f;
	private JButton logb;
	private JButton aboutusb;
	
	private JLabel imagelab;
	
	 public FrontPage()
	{
		
		f = new JFrame("WELCOME");
		logb = new JButton();
		logb.setText("Login");
		aboutusb = new JButton();
		aboutusb.setText("About us ");
		
		imagelab = new JLabel();
		
		//addActionListener
		logb.addActionListener(this);
		aboutusb.addActionListener(this);

		//add 
		f.add(logb);
		f.add(aboutusb);
		

		f.add(imagelab);
		
		logb.setBounds(625,150,130,35);
		aboutusb.setBounds(775,150,130,35);

		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		f.setSize(975,650);
		f.setLayout(null);
		//f.getContentPane().setBackground(new Color(135,106,135));
		//f.getContentPane().setBackground(new Color(255,255,153));
		//f.getContentPane().setBackground(new Color(204,204,204));
		f.getContentPane().setBackground(new Color(153,153,153));
		f.setVisible(true);
		f.setLocationRelativeTo(null);
		f.setResizable(false);
		 //icon setup
		 //ImageIcon icon = new ImageIcon("logicon5.png");
		 ImageIcon icon = new ImageIcon("C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\pictures\\logicon5.png");
		 
		 f.setIconImage(icon.getImage());

		//image setup
		//ImageIcon img = new ImageIcon("fronticon6.png");
		ImageIcon img = new ImageIcon("C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\pictures\\fronticon6.png");
		imagelab.setIcon(img);
		imagelab.setBounds(50,0,950,600);
		 
		
	}
	public void actionPerformed( ActionEvent e) {  
         
        if(e.getSource() == logb)
		{  

				new Login();
				f.setVisible(false);
			}
              
		else if(e.getSource() == aboutusb)
		{
			new AboutUs();
			f.setVisible(false);
		}
    }  
	
	
	
	
	
}
	