package userclasses;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import adminclasses.*;
public class UserDashboard extends JFrame {
    private JButton viewProfileButton;
    private JButton addCourseButton;
    private JButton ongoingQuizButton;
    private JButton upcomingQuizButton;
    private JButton historyButton;
    private JButton backButton;
    private JButton logoutButton;
    private String userEmail;


    public UserDashboard(String email,String username,String UserGender, String UserPass) {
        this.userEmail=email;
        setTitle("Dashboard");
        setSize(1000,650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        JPanel panel = new JPanel();
        panel.setLayout(null);
        JLabel welcomeLabel = new JLabel("Welcome to  Dashboard:  "+username);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setBounds(350, 0, 600, 100);
        panel.add(welcomeLabel);
        viewProfileButton = new JButton("View Profile");
        viewProfileButton.setBounds(80, 100, 225, 125);
        viewProfileButton.setFont(new Font("Comic Sans",Font.BOLD,17));
        panel.add(viewProfileButton);
        addCourseButton = new JButton("Available Courses");
        addCourseButton.setBounds(250, 300, 225, 125);
        addCourseButton.setFont(new Font("Comic Sans",Font.BOLD,17));
        panel.add(addCourseButton);
        ongoingQuizButton = new JButton("Ongoing Quiz");
        ongoingQuizButton.setBounds(690, 100, 225, 125);
        ongoingQuizButton.setFont(new Font("Comic Sans",Font.BOLD,17));
        panel.add(ongoingQuizButton);
        upcomingQuizButton = new JButton("Upcoming Quiz");
        upcomingQuizButton.setBounds(390, 100, 225, 125);
        upcomingQuizButton.setFont(new Font("Comic Sans",Font.BOLD,17));
        panel.add(upcomingQuizButton);
        historyButton = new JButton("History");
        historyButton.setBounds(550, 300, 225, 125);
        historyButton.setFont(new Font("Comic Sans",Font.BOLD,17));
        panel.add(historyButton);
       getContentPane().setBackground(new Color(255,255,204));
        //setBackground(Color.BLUE); 
        panel.setBackground(new Color(255,255,204));
        backButton = new JButton("Back");
        backButton.setBounds(20, 570, 100, 30);
        panel.add(backButton);
        logoutButton = new JButton("Log Out");
        logoutButton.setBounds(850, 570, 100, 30);
        panel.add(logoutButton);
        add(panel);
        viewProfileButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               new Profile(username,userEmail,UserGender,UserPass);
			  dispose();
            }
        });
       /*  addCourseButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                dispose();
                Sta staInstance = new Sta();


            }
        });*/

        addCourseButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        dispose();
                        /*Sta stInstance = new Sta();
        
                        // Call the main method of the St class
                        String[] args = {}; // Pass any necessary arguments to the main method
                        stInstance.main(args);


                       // Sta staInstance = new Sta();*/
                    }
                });
            }
        });
        

        ongoingQuizButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
				setVisible(false);
			new UserQuizes(username,userEmail,UserGender,UserPass);	
            }
        });
        upcomingQuizButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new DisplayQuiz();
                setVisible(true);
            }
        });
        historyButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new History(email);
                setVisible(true);

            }
        });
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
				dispose();
				new Login ();
            }
        });
        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int pulock = JOptionPane.showConfirmDialog(null, "Do you want to log out?", "Logout", JOptionPane.YES_NO_OPTION);
                if (pulock == JOptionPane.YES_OPTION) {
                    JOptionPane.showMessageDialog(null, "Logged out successfully");
					new Login();
			 dispose();
                }
            }
        });
        setVisible(true);
    }
}