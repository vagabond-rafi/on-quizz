package userclasses;
import java.lang.*;
import adminclasses.*;
    public class Question {
    private String questionNumber;
    private String question;
    private String[] options;
    private String correctIndex;

    public Question(String questionNumber, String question, String[] options, String correctIndex) {
        this.questionNumber = questionNumber;
        this.question = question;
        this.options = options;
        this.correctIndex = correctIndex;
    }

    public String getQuestionNumber() {
        return questionNumber;
    }

    public String getQuestion() {
        return question;
    }

    public String[] getOptions() {
        return options;
    }

    public String getCorrectIndex() {
        return correctIndex;
    }
}
