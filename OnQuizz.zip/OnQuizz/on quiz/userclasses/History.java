package userclasses;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class History {
    private String email;
	private JFrame frame;
	public History(String email) {
     this.email=email;

		        frame = new JFrame("History");
				 frame.setSize(600, 500);
        frame.setLayout(null);
		frame.setVisible(false);
        //frame.setVisible(true);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
	
        frame.setLocationRelativeTo(null);

		displayquizes();
        
	}
	
	 public void displayquizes() {
        try {
            File file = new File("marks.txt");
            if (!file.exists()) {
                JOptionPane.showMessageDialog(frame, "No History available!");
                return;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            StringBuilder quizesInfo = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if(parts.length == 4 && parts[1].equals(email)){
                String quizeInfo = String.format("Name: %s email: %s gender: %s Marks: %s\n",  parts[0], parts[1], parts[2], parts[3]);
                quizesInfo.append(quizeInfo);
            }
            }
            reader.close();

            JTextArea textArea = new JTextArea(quizesInfo.toString());
          textArea.setEditable(false);
           JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(600, 500));
            JOptionPane.showMessageDialog(frame, scrollPane, " History", JOptionPane.PLAIN_MESSAGE);

            
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
