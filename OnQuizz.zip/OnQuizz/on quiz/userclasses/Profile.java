package userclasses;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.*;
import adminclasses.*;
//import textfiles.*;
//import pictures.*;
 
public class Profile implements ActionListener {
    private Container c;
    private JFrame frame;
	private JLabel label;
    private Cursor cursor;
    private JPanel panel;
    private JLabel fullName1;
    private JLabel displayName1;
    private JLabel phoneNumber1;
    private JLabel oldPassword1;
    private JLabel userName1;
	private JLabel userName2;
    private JButton editButton;
    private JButton logoutButton;
    private JButton backButton;
    private JTextField userEmailField;
	private JTextField userNameField;
	private String Name;
	private String Email;
	private String Password;
	private String Gender;
	
 
    public Profile(String name,String email,String UserGender,String UserPass) {
		this.Name=name;
		this.Email=email;
		this.Gender=UserGender;
		this.Password=UserPass;
        System.out.println(email);
        frame = new JFrame();
        frame.setSize(1000,650);
        frame.setTitle("Profile");
        frame.setLayout(null);
        frame.setVisible(true);
        c = frame.getContentPane();
        c.setBackground(Color.decode("#24292e"));
        frame.setLocationRelativeTo(null);
		//frame.setResizeable(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //ImageIcon icon = new ImageIcon("pictureprof.png");
        ImageIcon icon = new ImageIcon("C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\pictures\\pictureprof.png");

        frame.setIconImage(icon.getImage());
        frame.setLocationRelativeTo(null);
        cursor = new Cursor(Cursor.HAND_CURSOR);
 
        // Profile Information Section
        displayName1 = new JLabel("Profile Information");
        displayName1.setBounds(300, 150, 200, 50);
        Font displayName1Font = new Font("Times New Roman", Font.PLAIN, 25);
        displayName1.setFont(displayName1Font);
        displayName1.setForeground(Color.decode("#6577b3"));
        frame.add(displayName1);
		userName2 = new JLabel("User Name:");
		userName2.setBounds(180,220,200,50);
		Font userName2Font = new Font("Times New Roman", Font.PLAIN, 22);
		userName2.setFont(userName2Font);
		userName2.setForeground(Color.decode("#8ee0f0"));
		frame.add(userName2);
		
		userNameField = new JTextField();
		userNameField.setBounds(300,220,180,50);
		userNameField.setText(name);
		frame.add(userNameField);
		
        userName1 = new JLabel("User Email:");
        userName1.setBounds(180, 320, 200, 50);
        Font userName1Font = new Font("Times New Roman", Font.PLAIN, 22);
        userName1.setFont(userName1Font);
        userName1.setForeground(Color.decode("#8ee0f0"));
        frame.add(userName1);
 
        userEmailField = new JTextField();
        userEmailField.setBounds(300, 320, 180, 50);
        userEmailField.setText(email);
        frame.add(userEmailField);
 
        // Buttons
        editButton = new JButton("Edit Info");
        editButton.setBounds(368, 390, 80, 30);
        editButton.setBackground(new Color(0, 0, 0, 0));
        editButton.setBorder(BorderFactory.createEmptyBorder());
        editButton.setForeground(Color.decode("#6577b3"));
        editButton.setOpaque(false);
        Font editButtonFont = new Font("Times New Roman", Font.BOLD, 19);
        editButton.setFont(editButtonFont);
        editButton.setCursor(cursor);
        frame.add(editButton);
 
        backButton = new JButton("Back");
        backButton.setBounds(0, 480, 100, 30);
        backButton.setBackground(Color.white);
        frame.add(backButton);
 
        logoutButton = new JButton("Logout");
        logoutButton.setBounds(740, 480, 100, 30);
        logoutButton.setBackground(Color.white);
        frame.add(logoutButton);
 
     
 
        // Action Listeners
        logoutButton.addActionListener(this);
        editButton.addActionListener(this);
        backButton.addActionListener(this);
      
    }
 
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == logoutButton) {
            // Logout action
			 int pulock = JOptionPane.showConfirmDialog(null, "Do you want to log out?", "Logout", JOptionPane.YES_NO_OPTION);
                if (pulock == JOptionPane.YES_OPTION) {
                    JOptionPane.showMessageDialog(null, "Logged out successfully");
					new Login();
			   frame.dispose();
                }
			 
        } else if (e.getSource() == editButton) {
            new NewEdit(Name,Email,Gender,Password);
           frame.dispose();
        } else if (e.getSource() == backButton) {
            // Back action
			new UserDashboard(Email,Name,Gender,Password);
			frame.dispose();
        }  else {
            // Default action
        }
    }
}

