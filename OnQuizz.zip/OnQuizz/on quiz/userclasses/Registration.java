package userclasses;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import adminclasses.*;
//import textfiles.*;
//import pictures.*;

public class Registration implements ActionListener {
    private JFrame frame;
    private JTextField nameField, emailField, backField;
    private JPasswordField passwordField;
    private JComboBox<String> genderBox;
	private JCheckBox showHideCheckBox;
	
        JLabel labelm = new JLabel();
    public Registration() {
        frame = new JFrame("Registration");
        frame.setSize(1000,650);
        frame.setLayout(null);

        JLabel nameLabel = new JLabel("       Name:");
        nameLabel.setBounds(20, 50, 100, 30);
		nameLabel.setBackground(Color.orange);
		nameLabel.setOpaque(true);
		nameLabel.setFont(new Font("Arial", Font.PLAIN,14));
        frame.add(nameLabel);
        frame.add(labelm);
        nameField = new JTextField();
        nameField.setBounds(150, 50, 200, 30);
        frame.add(nameField);

        JLabel emailLabel = new JLabel("       Email:");
        emailLabel.setBounds(20, 100, 100, 30);
        frame.add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(150, 100, 200, 30);
		emailLabel.setBackground(Color.orange);
		emailLabel.setOpaque(true);
		emailLabel.setFont(new Font("Arial", Font.PLAIN,14));
		
        frame.add(emailField);

        JLabel passwordLabel = new JLabel("     Password:");
        passwordLabel.setBounds(20, 150, 100, 30);
		passwordLabel.setBackground(Color.orange);
		passwordLabel.setOpaque(true);
		passwordLabel.setFont(new Font("Arial", Font.PLAIN,14));
		

        frame.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(150, 150, 200, 30);
        frame.add(passwordField);



        JLabel genderLabel = new JLabel("       Gender:");
        genderLabel.setBounds(20, 200, 100, 30);
		genderLabel.setBackground(Color.orange);
		genderLabel.setOpaque(true);
		genderLabel.setFont(new Font("Arial", Font.PLAIN,14));
        frame.add(genderLabel) ;
		
		
		
		 showHideCheckBox = new JCheckBox("Show Password");
        showHideCheckBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (showHideCheckBox.isSelected()) {
                    passwordField.setEchoChar((char) 0); // Show password
                } else {
                    passwordField.setEchoChar('*'); // Hide password
                }
            }
        });
		
		//ImageIcon image=new ImageIcon("logo1.png");
        ImageIcon image=new ImageIcon("C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\pictures\\logo1.png");

		frame.setIconImage(image.getImage());
		
		
		//ImageIcon image1= new ImageIcon("pic.png");
        ImageIcon image1= new ImageIcon( "C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\pictures\\pic.png");
		labelm.setIcon(image1);
		labelm.setBounds(500,150,383,385);
		
   
        String[] genders = {" ","Male", "Female", "Other"};
        genderBox = new JComboBox<>(genders);
        genderBox.setBounds(150, 200, 200, 30);
        frame.add(genderBox);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(180, 300, 100, 30);
        registerButton.addActionListener(this);
        frame.add(registerButton);

        JButton clearButton = new JButton("Clear");
        clearButton.setBounds(290, 300, 100, 30);
        clearButton.addActionListener(this);
        frame.add(clearButton);

     JButton backButton = new JButton("Back");
        backButton.setBounds(10, 510, 100, 30);
        backButton.addActionListener(this);
        frame.add(backButton);
		 
		 frame.add(showHideCheckBox);
		  showHideCheckBox.setBounds(370, 150, 130, 35);
		  
		  
        JLabel loginLabel = new JLabel("Already Registered? Login");
        loginLabel.setForeground(Color.BLUE);
        loginLabel.setBounds(210, 350, 200, 30);
		
		
        loginLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        loginLabel.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                frame.dispose();
                new Login();
            }
        });
		
        frame.add(loginLabel);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
	
		
		
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton button = (JButton) e.getSource();
            if (button.getText().equals("Register")) {
                register();
            } else if (button.getText().equals("Clear")) {
                clearFields();
            }
			else if (button.getText().equals("Back")) {
                frame.dispose();
				new Login();
            }
        }
    }

    private void register() {
        String name = nameField.getText();
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());
        String gender = (String) genderBox.getSelectedItem();

        // Check for empty fields
        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill all fields!");
            return;
        }

        // Check for existing email
        if (isEmailExists(email)) {
            JOptionPane.showMessageDialog(frame, "User with this email already exists!");
            return;
        }

        User newUser = new User(name, email, password, gender);

        try {
            FileWriter writer = new FileWriter("userdata.txt", true);
           

            writer.write(newUser.getName() + "," + newUser.getEmail() + "," + newUser.getPassword() + "," + newUser.getGender() + "\n");
            writer.close();
            JOptionPane.showMessageDialog(frame, "Registration Successful!");
            frame.dispose();
            new Login();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private boolean isEmailExists(String email) {
        try {
            File file = new File("userdata.txt");
            if (!file.exists()) {
                return false;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[1].equals(email)) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    private void clearFields() {
        nameField.setText("");
        emailField.setText("");
        passwordField.setText("");
        genderBox.setSelectedIndex(0);
    }
}
