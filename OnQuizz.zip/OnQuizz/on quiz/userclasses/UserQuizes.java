package userclasses;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import adminclasses.*;
//import textfiles.*;
//import pictures.*;
public class UserQuizes extends JFrame implements ActionListener {
    JButton quiz2Button,quiz1Button,logoutButton,bb;
	JLabel cimagelab,javaimagelab;
	 JFrame f;
	 private String email;
     private String username;
     private String usergender;
     private String UserPass;
	
	
	 public UserQuizes(String email,String username,String usergender,String UserPass) {
        this.email=email;
        this.username=username;
        this.usergender=usergender;
        this.UserPass=UserPass;

        setTitle("Ongoing quizes");
      
       f=new JFrame("Select your quiz");
      

        quiz1Button = new JButton("Quiz 1 on c++ ");
        quiz2Button = new JButton("Quiz 2 on JAVA ");
         logoutButton = new JButton("Logout");
         bb= new JButton("Back");

		 cimagelab = new JLabel();
		  javaimagelab = new JLabel();
		 
        quiz1Button.setBounds(50,50,225,125);
		quiz2Button.setBounds(200,230,225,125);
		logoutButton.setBounds(350,460,100,35);
        bb.setBounds(10,460,100,35);

		
         quiz1Button.addActionListener(this);
         quiz2Button.addActionListener(this);
		 logoutButton.addActionListener(this);
         bb.addActionListener(this);

		  f.add(quiz1Button);
          f.add(quiz2Button);
          f.add(logoutButton);
          f.add(bb);
		  
		f.add(cimagelab);
        f.add(javaimagelab);
		
		
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
	
	  f.setSize(500,550);
	  f.setLayout(null);
      
        f.setVisible(true);
		  f.setLocationRelativeTo(null);
		  
		  
		//ImageIcon img = new ImageIcon("c++pic.png");
        ImageIcon img = new ImageIcon("C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\pictures\\c++pic.png");

		cimagelab.setIcon(img);
		cimagelab.setBounds(320,70,150,75);
		
		  
		//ImageIcon icon = new ImageIcon("javapic.png");
        ImageIcon icon = new ImageIcon("C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\pictures\\javapic.png");
		javaimagelab.setIcon(icon);
		javaimagelab.setBounds(10,250,150,75);
        
	
	 }
	//String qs1fileName = "questions.txt";
	
	public void actionPerformed(ActionEvent e) {
        if (e.getSource() == quiz1Button) {
           f.setVisible(false);
		   
		   int pulock = JOptionPane.showConfirmDialog(null, "Do you want to give quiz now?", "Confirmation", JOptionPane.YES_NO_OPTION);
                if (pulock == JOptionPane.YES_OPTION) {
                     new Quiz("Quiz of C++","questions.txt",email,username,usergender,UserPass);
                }
		  
		 if (pulock == JOptionPane.NO_OPTION) {
                   // JOptionPane.showMessageDialog(null, "OK");
				   new UserQuizes(email,username,usergender,UserPass);
                }
			
        } else if (e.getSource() == quiz2Button) {
            f.setVisible(false);
          		   int valid = JOptionPane.showConfirmDialog(null, "Do you want to give quiz now?", "Confirmation", JOptionPane.YES_NO_OPTION);
                if (valid == JOptionPane.YES_OPTION) {
                    new Quiz("Quiz of JAVA","quiz2questions.txt",email,username,usergender,UserPass);
                }
		  
		 if (valid == JOptionPane.NO_OPTION) {
                   // JOptionPane.showMessageDialog(null, "OK");
				   //new UserQuizes(email,username,UserGender)
                   f.setVisible(true);
                }
			
        }
		else if (e.getSource() == logoutButton) {
           f.setVisible(false); 
	      new Login();
			
        }
        else if (e.getSource() == bb) {
            f.setVisible(false); 
           new UserDashboard(email,username,usergender,UserPass);
           
         }
		
		
		
    }
	
	
	
	
	
	
	
	
}