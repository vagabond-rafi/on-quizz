import java.lang.*;
import userclasses.*;
import adminclasses.*;



public class Start
{
	public static void main(String[] args)
    {
		//new Login();
		//new AboutUs();
	    new FrontPage();
		//new UserQuizes("y76r","iiut76","jrt","gjyg");
		//new Quiz("Quiz of C++","questions.txt","y76r","iiut76","jrt","jgg");
	      //new UserDashboard("y76r","iiut76","jrt","hff");
		//new History("s");
		
		
		
}   
}