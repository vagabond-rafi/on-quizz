package upcomingquiz;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class AddQuiz implements ActionListener {
    private JFrame frame;
    private JTextField nameField, codeField;

    public AddQuiz() {
        frame = new JFrame("Add Quiz");
        frame.setSize(600, 500);
        frame.setLayout(null);

        JLabel nameLabel = new JLabel("Add Quiz");
        nameLabel.setBounds(250, 20, 100, 30);
		
        frame.add(nameLabel);
		
		
		
		 JButton displayButton = new JButton("Display");
        displayButton.setBounds(370, 280, 100, 30);
        displayButton.addActionListener(this);
        frame.add(displayButton);
		

       
		
		

        JLabel nameLabel2 = new JLabel("QUIZ NAME:");
        nameLabel2.setBounds(10, 60, 100, 30);
		nameLabel2.setBackground(Color.orange);
		nameLabel2.setOpaque(true);
		nameLabel2.setFont(new Font("Arial", Font.PLAIN,10));
        frame.add(nameLabel2);

        nameField = new JTextField();
        nameField.setBounds(150, 60, 200, 30);
        frame.add(nameField);

        JLabel codeLabel = new JLabel("QUIZ CODE:");
        codeLabel.setBounds(10, 100, 100, 30);
		codeLabel.setBackground(Color.orange);
		codeLabel.setOpaque(true);
		codeLabel.setFont(new Font("Arial", Font.PLAIN,10));
        frame.add(codeLabel);

        codeField = new JTextField();
        codeField.setBounds(150, 100, 200, 30);
        frame.add(codeField);

        
        JButton addButton = new JButton("Add");
        addButton.setBounds(150, 280, 100, 30);
        addButton.addActionListener(this);
        frame.add(addButton);

        JButton clearButton = new JButton("Clear");
        clearButton.setBounds(260, 280, 100, 30);
        clearButton.addActionListener(this);
        frame.add(clearButton);
		JButton backButton = new JButton("Back");
        backButton.setBounds(50, 400, 100, 30);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });
        frame.add(backButton);

        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton button = (JButton) e.getSource();
            if (button.getText().equals("Add")) {
                addQuiz();
            } else if (button.getText().equals("Clear")) {
                clearFields();
            }
			else if (button.getText().equals("Display")) {
				displayquizes();
               // clearFields();
            }
			
        }
    }

    private void addQuiz() {
        String name = nameField.getText();
        String code = codeField.getText();
        
       

        if (name.isEmpty() || code.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill all fields!");
            return;
        }
	}

 public void displayquizes() {
        try {
            File file = new File("quizes.txt");
            if (!file.exists()) {
                JOptionPane.showMessageDialog(frame, "No quizes available!");
                return;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            StringBuilder quizesInfo = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String quizeInfo = String.format("Name: %s, Code: %s",  parts[0], parts[1]);
                quizesInfo.append(quizeInfo);
            }
            reader.close();

            JTextArea textArea = new JTextArea(quizesInfo.toString());
            textArea.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(400, 300));
            JOptionPane.showMessageDialog(frame, scrollPane, "Available quizes", JOptionPane.PLAIN_MESSAGE);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void updatequize() {
        String code = JOptionPane.showInputDialog(frame, "Enter code of the quize to update:");
        if (code == null || code.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "code cannot be empty!");
            return;
        }/*
		frame.dispose();
		new Updatequize(code, new Managequizes());
       /* String[] lines = new String[100]; // Assuming a maximum of 100 lines/quizes
        int count = 0;

        try {
            File file = new File("quizes.txt");
            if (!file.exists()) {
                JOptionPane.showMessageDialog(frame, "No quizes available!");
                return;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[1].equals(code)) {
                    String title = JOptionPane.showInputDialog(frame, "Enter new title:");
                    String author = JOptionPane.showInputDialog(frame, "Enter new author:");
                    double price = Double.parseDouble(JOptionPane.showInputDialog(frame, "Enter new unit price:"));
                    int quantity = Integer.parseInt(JOptionPane.showInputDialog(frame, "Enter new quantity:"));
                    line = String.join(",", title, code, author, Double.toString(price), Integer.toString(quantity));
                }
                lines[count++] = line;
            }
            reader.close();

            FileWriter writer = new FileWriter(file);
            for (int i = 0; i < count; i++) {
                writer.write(lines[i] + "\n");
            }
            writer.close();

            JOptionPane.showMessageDialog(frame, "quize information updated successfully!");
        } catch (IOException ex) {
            ex.printStackTrace();
        }*/
    }







    private void clearFields() {
        nameField.setText("");
        codeField.setText("");
       
       
    }

    private boolean isCODEExists(String code) {
        try {
            File file = new File("Quizes.txt");
            if (!file.exists()) {
                return false;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length > 1 && parts[1].equals(code)) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
    }
}


