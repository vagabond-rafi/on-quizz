import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class DisplayQuiz {
	private JFrame frame;
	public DisplayQuiz() {
		        frame = new JFrame("Add Quiz");
				 frame.setSize(600, 500);
        frame.setLayout(null);
		frame.setVisible(false);
		displayquizes();
	}
	
	 public void displayquizes() {
        try {
            File file = new File("quizes.txt");
            if (!file.exists()) {
                JOptionPane.showMessageDialog(frame, "No quizes available!");
                return;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            StringBuilder quizesInfo = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String quizeInfo = String.format("Name: %s, Code: %s",  parts[0], parts[1]);
                quizesInfo.append(quizeInfo);
            }
            reader.close();

            JTextArea textArea = new JTextArea(quizesInfo.toString());
            textArea.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(400, 300));
            JOptionPane.showMessageDialog(frame, scrollPane, "Available quizes", JOptionPane.PLAIN_MESSAGE);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
