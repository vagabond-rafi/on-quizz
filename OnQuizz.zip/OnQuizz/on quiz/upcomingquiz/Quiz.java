import java.io.Serializable;

public class Quiz implements Serializable {
    private String name;
    private String code;
   
    

    public Quiz(String name, String code) {
        this.name = name;
        this.code = code;
              
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    
    @Override
    public String toString() {
        return "Name: " + name +
                "\nCode: " + code ;
                             
}
}

