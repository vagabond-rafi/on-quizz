package adminclasses;

import java.io.*;
import java.util.Scanner;
import userclasses.*;
public class CoursesFileIO{
	
	public static void loadCoursesFromFile(CourseList courseList){
		try{
			Scanner sc=new Scanner(new File("courses.txt")); 
			while(sc.hasNextLine()){
				String data[] = sc.nextLine().split(";");

				String id = data[0];
				String courseName = data[1];
				String courseCode = data[2];
				String courseType = data[3];
				int copy = Integer.parseInt(data[4]);
				String image = data[5];

				Course b = new Course(id,courseName,courseCode,courseType,copy,image);
				courseList.insert(b);
			}
			sc.close();
		}
		catch(Exception e){
			System.out.println("Cannot Read the File");
			e.printStackTrace();
		}
	}
	
	public static void insertInFile(String line, String fname){
		try {
		FileWriter writer = new FileWriter(fname,true);
		writer.write(line+"\n");
		writer.close();
		} catch (IOException e) {
			System.out.println("Cannot Write in File");
		}
	}
	
	public static void saveCoursesInFile(CourseList courseList){
		try {
		FileWriter writer = new FileWriter("courses.txt");
		Course courses[] = courseList.getAllCourses();
		
		for(int i=0;i<courses.length;i++){
			if(courses[i]!=null){
				writer.write(courses[i].getCourseInfoAsString()+"\n");
			}
		}
		
		writer.close();
		} catch (IOException e) {
			System.out.println("Cannot Write in File");
		}
	}
}
