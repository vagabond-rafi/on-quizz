package adminclasses;
import userclasses.*;


public class CourseList{
	private Course courses[];
	public CourseList(){
		courses = new Course[5];
	}
	public CourseList(int size){
		courses = new Course[size];
	}
	
	public void insert(Course b){
		boolean flag = false;
		for(int i=0;i<courses.length;i++){
			if(courses[i] == null){
				courses[i] = b;
				flag = true;
				break;
			}
		}
		if(flag){System.out.println("Insertion Successfull");}
		else{System.out.println("Insertion Failed");}
	}
	
	public Course getById(String id){
		for(int i=0;i<courses.length;i++){
			if(courses[i] != null){
				if(courses[i].getCourseId().equals(id)){
					return courses[i];
				}
			}
		}
		return null;
	}
	
	public void deleteById(String id){
		boolean flag = false;
		for(int i=0;i<courses.length;i++){
			if(courses[i] != null){
				if(courses[i].getCourseId().equals(id)){
					courses[i] = null;
					flag = true;
					break;
				}
			}
		}
		if(flag){System.out.println("Deletion Successfull");}
		else{System.out.println("Deletion Failed");}
	}
	
	
	public void searchByName(String name){
		for(int i=0;i<courses.length;i++){
			if(courses[i] != null){
				if(courses[i].getCourseName().equals(name)){
					System.out.println("+++ Course Found +++");
					courses[i].showCourseInfo();
					return;
				}
			}
		}
		System.out.println("-- Course Not Found ---");
		return;
	}
	
	public void showAll(){
		System.out.println("++++++ List of All Available Courses ++++++");
		for(int i=0;i<courses.length;i++){
			if(courses[i] != null){ //looking for course objects
			System.out.println("---------------------");
				courses[i].showCourseInfo();
			}
		}
		System.out.println("---------------------");
	}
	
	public String getAll(){
		String allCourses = "";
		
		for(int i=0;i<courses.length;i++){
			if(courses[i] != null){ //looking for course objects
				allCourses += "------------------------\n";
				allCourses += courses[i].getCourseInfoAsString();
			}
		}
		allCourses += "------------------------\n";
		return allCourses;
	}
	
	public Course[] getAllCourses(){
		return courses;
	}
	
}