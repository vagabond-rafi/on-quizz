package adminclasses;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class AddQuiz implements ActionListener {
    private JFrame frame;
    private JTextField nameField, codeField;

    public AddQuiz() {
        frame = new JFrame("Add UpcomingQuiz");
        frame.setSize(600, 500);
        frame.setLayout(null);

        JLabel nameLabel = new JLabel("Add ");
        nameLabel.setBounds(250, 20, 100, 30);
		
        frame.add(nameLabel);
		
		
		
		 JButton displayButton = new JButton("Display");
        displayButton.setBounds(370, 280, 100, 30);
        displayButton.addActionListener(this);
        frame.add(displayButton);
		

       
		
		

        JLabel nameLabel2 = new JLabel("QUIZ Title:");
        nameLabel2.setBounds(10, 60, 100, 30);
		nameLabel2.setBackground(Color.orange);
		nameLabel2.setOpaque(true);
		nameLabel2.setFont(new Font("Arial", Font.PLAIN,10));
        frame.add(nameLabel2);

        nameField = new JTextField();
        nameField.setBounds(150, 60, 200, 30);
        frame.add(nameField);

        JLabel codeLabel = new JLabel("QUIZ CODE:");
        codeLabel.setBounds(10, 100, 100, 30);
		codeLabel.setBackground(Color.orange);
		codeLabel.setOpaque(true);
		codeLabel.setFont(new Font("Arial", Font.PLAIN,10));
        frame.add(codeLabel);

        codeField = new JTextField();
        codeField.setBounds(150, 100, 200, 30);
        frame.add(codeField);

        
        JButton addButton = new JButton("Add");
        addButton.setBounds(150, 280, 100, 30);
        addButton.addActionListener(this);
        frame.add(addButton);

        JButton clearButton = new JButton("Clear");
        clearButton.setBounds(260, 280, 100, 30);
        clearButton.addActionListener(this);
        frame.add(clearButton);
		JButton backButton = new JButton("Back");
        backButton.setBounds(50, 400, 100, 30);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
				new AdminDashboard();
            }
        });
        frame.add(backButton);

        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton button = (JButton) e.getSource();
            if (button.getText().equals("Add")) {
                addQuiz();
                frame.setVisible(true);
                //new AdminDashboard();
            } else if (button.getText().equals("Clear")) {
                clearFields();
            }
			else if (button.getText().equals("Display")) {
				displayquizes();
                clearFields();
                frame.setVisible(true);
                //new AdminDashboard();
            }
			
        }
    }

    private void addQuiz() {
        String name = nameField.getText();
        String code = codeField.getText();
        
       

        if (name.isEmpty() || code.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill all fields!");
            return;
        }
	

        try {
            // Check if the CODE already exists in the file
            if (isCODEExists(code)) {
                JOptionPane.showMessageDialog(frame, "QUIZ with the same CODE already exists!");
                clearFields(); // Clear all fields
                return;
            }

            UpQuiz newQuiz = new UpQuiz(name, code);

            FileWriter writer = new FileWriter("quizes.txt", true);
            writer.write(newQuiz.getName() + "," + newQuiz.getCode() + "," +"\n");
            writer.close();

            JOptionPane.showMessageDialog(frame, "Quiz added successfully!");
            frame.dispose(); // Close the add QUIZ window
        } catch (NumberFormatException | IOException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid price or quantity format!");
        }
    }
	
	
	
	

 public void displayquizes() {
        try {
            File file = new File("quizes.txt");
            if (!file.exists()) {
                JOptionPane.showMessageDialog(frame, "No quizes available!");
                return;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            StringBuilder quizesInfo = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String quizeInfo = String.format("Name: %s, Code: %s\n",  parts[0], parts[1]);
                quizesInfo.append(quizeInfo);
            }
            reader.close();

            JTextArea textArea = new JTextArea(quizesInfo.toString());
            textArea.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(400, 300));
            JOptionPane.showMessageDialog(frame, scrollPane, "Available quizes", JOptionPane.PLAIN_MESSAGE);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void updatequize() {
        String code = JOptionPane.showInputDialog(frame, "Enter code of the quize to update:");
        if (code == null || code.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "code cannot be empty!");
            return;
        }
    }







    private void clearFields() {
        nameField.setText("");
        codeField.setText("");
       
       
    }

    private boolean isCODEExists(String code) {
        try {
            File file = new File("Quizes.txt");
            if (!file.exists()) {
                return false;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length > 1 && parts[1].equals(code)) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
    }
}


