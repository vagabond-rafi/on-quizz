package adminclasses;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import userclasses.*;
//import textfiles.*;
//import pictures.*;

public class UpdateUser implements ActionListener {
    private JFrame frame;
    private JTextField nameField, emailField;
    private JPasswordField passwordField;
    private JRadioButton maleRadioButton, femaleRadioButton, otherRadioButton;
    private JButton saveButton, cancelButton,bb;
    private ManageUsers manageUsers;
    //private String gender;

    public UpdateUser() {
        


        frame = new JFrame("Update user info ");
        frame.setSize(600, 500);
        frame.setLayout(null);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(50, 30, 100, 30);
        frame.add(nameLabel);
		
        nameField = new JTextField();
        nameField.setBounds(150, 30, 200, 30);
        frame.add(nameField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(50, 70, 100, 30);
        frame.add(emailLabel);
		
        emailField = new JTextField();
        emailField.setBounds(150, 70, 200, 30);
        frame.add(emailField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 110, 100, 30);
        frame.add(passwordLabel);
		
        passwordField = new JPasswordField();
        passwordField.setBounds(150, 110, 200, 30);
        frame.add(passwordField);

        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setBounds(50, 150, 100, 30);
        frame.add(genderLabel);

        ButtonGroup genderGroup = new ButtonGroup();
		
        maleRadioButton = new JRadioButton("Male");
        maleRadioButton.setBounds(150, 150, 80, 30);
        maleRadioButton.setActionCommand("Male");
		
        femaleRadioButton = new JRadioButton("Female");
        femaleRadioButton.setBounds(240, 150, 80, 30);
        femaleRadioButton.setActionCommand("Female");
		
        otherRadioButton = new JRadioButton("Other");
        otherRadioButton.setBounds(330, 150, 80, 30);
        otherRadioButton.setActionCommand("Other");

        // Here you need to set the selected radio button based on originalGender value.

        genderGroup.add(maleRadioButton);
        genderGroup.add(femaleRadioButton);
        genderGroup.add(otherRadioButton);
		
        frame.add(maleRadioButton);
        frame.add(femaleRadioButton);
        frame.add(otherRadioButton);

        saveButton = new JButton("Save");
        saveButton.setBounds(110, 220, 100, 30);
        saveButton.addActionListener(this);
        frame.add(saveButton);

        cancelButton = new JButton("Cancel");
        cancelButton.setBounds(230, 220, 100, 30);
        cancelButton.addActionListener(this);
        frame.add(cancelButton);

          bb = new JButton("Back");
        bb.setBounds(10, 410, 100, 30);
       bb.addActionListener(this);
        frame.add(bb);



        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton button = (JButton) e.getSource();
            if (button.getText().equals("Save")) {
               editQuestion();
				
            } else if (button.getText().equals("Cancel")) {
                frame.dispose();
				new ManageUsers();
               
            }
			else if (button.getText().equals("Back")) {
                frame.dispose();
				new ManageUsers();
            }
        }
    }
private boolean isEmailExists( String email) {
        try {
            File file = new File("userdata.txt");
            if (!file.exists()) {
                return false;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length== 4 && parts[1].equals(email)) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
    }
    private void clearFields() {
        nameField.setText("");
         emailField.setText("");
         passwordField.setText("");
		 passwordField.setText("");
		
    }

		
		
    private void editQuestion() {
    String name = nameField.getText();
    String email = emailField.getText();
    String password = passwordField.getText();
   
   String gender = null;
   if (maleRadioButton.isSelected()) {
             gender = maleRadioButton.getText() ;
        } else if (femaleRadioButton.isSelected()) {
           gender = femaleRadioButton.getText();
        } else if (otherRadioButton.isSelected()){
            gender = otherRadioButton.getText();
        }
		else {
        JOptionPane.showMessageDialog(frame, "Please select a gender!");
        return; // Return without proceeding further if gender is not selected
       }
	   
    if (name.isEmpty() || email.isEmpty() || password.isEmpty() || gender.isEmpty() ) {
            JOptionPane.showMessageDialog(frame, "Please fill all boxes!");
            return;
        }
		
   
		
  
		
   
   String[] editeduser = {name,email,password,gender};
   
if (isEmailExists(email)) {
           // JOptionPane.showMessageDialog(frame, "User with this email already exists!");
            
    try {
        BufferedReader reader = new BufferedReader(new FileReader("userdata.txt"));
        String line;
        StringBuilder fileContent = new StringBuilder();
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length == 4 && parts[1].equals(email)) {
                line = String.join(",", editeduser);
            }
            fileContent.append(line).append("\n");
        }
        reader.close();

        BufferedWriter writer = new BufferedWriter(new FileWriter("userdata.txt"));
        writer.write(fileContent.toString());
        writer.close();
        JOptionPane.showMessageDialog(frame, "User info edited successfully.");
		clearFields();
    } catch (IOException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(frame, "Failed to edit user info.");
    }
}
else {
	JOptionPane.showMessageDialog(frame, "No user exist with this email!");
}


}
	
}
