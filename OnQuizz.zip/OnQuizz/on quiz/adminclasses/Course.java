package adminclasses;
import userclasses.*;
public class Course{
	private String courseId;
	private String courseName;
	private String courseCode;
	private String courseType;
	private int courseCredit;
	private String image;
	
	private static int courseCounter=0;
	
	public Course(){}
	public Course(String courseId,String courseName,String courseCode,String courseType,int courseCredit){
		this.courseName=courseName;
		this.courseCode=courseCode;
		this.courseId=courseId;
		this.courseType=courseType;
		this.courseCredit=courseCredit;
		courseCounter++;
	}
	public Course(String courseId,String courseName,String courseCode,String courseType,int courseCredit, String image){
		this.courseName=courseName;
		this.courseCode=courseCode;
		this.courseId=courseId;
		this.courseType=courseType;
		this.courseCredit=courseCredit;
		this.image = image;
		courseCounter++;
	}
	
	public void setCourseName(String courseName){
		this.courseName=courseName;
	}
	
	public void setCourseCode(String courseCode){
		this.courseCode=courseCode;
	}
	
	public void setCourseId(String courseId){
		this.courseId=courseId;
	}
	
	public void setCourseType(String courseType){
		this.courseType=courseType;
	}
	
	public void setCourseCredit(int courseCredit){
		this.courseCredit=courseCredit;
	}
	
	public String getCourseName(){return courseName;}
	public String getCourseCode(){return courseCode;}
	public String getCourseId(){return courseId;}
	public int getCourseCredit(){return courseCredit;}
	public String getCourseType(){return courseType;}
	
	public void setImage(String image){
		this.image=image;
	}
	public String getImage(){return image;}
	
	public void showCourseInfo(){
		System.out.println("Course Name : "+courseName);
		System.out.println("Course Code : "+courseCode);
		System.out.println("Course Id : "+courseId);
		System.out.println("Course Type : "+courseType);
		System.out.println("Number of Course Credit : "+courseCredit);
	}
	
	public void addCourseCredit(int x){
		courseCredit += x;
	}
	
	public static void totalNumberOfUniqueCourses(){
		System.out.println("Total Number Of Unique Courses : " + courseCounter);
	}
	
	public String getCourseInfoAsString(){
		return courseId+";"+courseName+";"+courseCode+";"+courseType+";"+courseCredit+";"+image;
	}
	

	
}