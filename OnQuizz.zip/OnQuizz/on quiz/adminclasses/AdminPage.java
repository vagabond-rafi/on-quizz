package adminclasses;



import java.util.Scanner;
import userclasses.*;
public class AdminPage {
    private CourseList courseList;

    public AdminPage(CourseList courseList) {
        this.courseList = courseList;
    }

    public void addCourse() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter Course ID:");
        String courseId = scanner.next();
        scanner.nextLine(); // Consume newline
        System.out.println("Enter Course Name:");
        String courseName = scanner.nextLine();
        System.out.println("Enter Course Code:");
        String courseCode = scanner.nextLine();
        System.out.println("Enter Course Type:");
        String courseType = scanner.nextLine();
        System.out.println("Enter Course Credit:");
        int credit = scanner.nextInt();

        Course course = new Course(courseId, courseName, courseCode, courseType, credit);
        courseList.insert(course);
    }
}
