package adminclasses;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.awt.Color;
import userclasses.*;
//import textfiles.*;
//import pictures.*;

public class ManageQuestion extends JFrame implements ActionListener {
    JTextArea questionArea, option1Area, option2Area, option3Area, option4Area;
    JTextField questionNumberField, correctIndexField;
    JButton addButton, editButton, deleteButton, saveButton, bb;
 
	JLabel qsn,qs,op1,op2,op3,op4,carind,smslab;
    
    JFrame f;
	String fileName ;
	
    public ManageQuestion(String fn) {
		
		fileName = fn;
		
        setTitle("Admin Panel");
      
        //panel.setLayout(new GridLayout(8, 2));
	
       f=new JFrame("welcome");
        questionNumberField = new JTextField();
        questionArea = new JTextArea();
        option1Area = new JTextArea();
        option2Area = new JTextArea();
        option3Area = new JTextArea();
        option4Area = new JTextArea();
        correctIndexField = new JTextField();
          questionNumberField.setBounds(200,10,130,35);
          questionArea.setBounds(200,70,430,35);
	      option1Area.setBounds(200,110,200,35);
          option2Area.setBounds(200,150,200,35);
          option3Area.setBounds(200,190,200,35);
          option4Area.setBounds(200,230,200,35);
          correctIndexField.setBounds(200,270,130,35);


        addButton = new JButton("Add");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        saveButton = new JButton("Save");
		bb = new JButton("Back");
		f.add(bb);
		
		
        addButton.setBounds(50,500,130,30);
		editButton.setBounds(300,500,130,30);
		deleteButton.setBounds(550,500,130,30);
		saveButton.setBounds(800,500,130,30);
	    bb.setBounds(50,550,130,30);
		
		
        addButton.addActionListener(this);
        editButton.addActionListener(this);
        deleteButton.addActionListener(this);
        saveButton.addActionListener(this);
		 bb.addActionListener(this);
		
		
        qsn=new JLabel("Question Number: ");
         f.add(qsn);
		qsn.setBounds(50,10,130,35);
        f.add(questionNumberField);
		
		qs=new JLabel("Question : ");
        f.add(qs);
		qs.setBounds(50,70,130,35);
        f.add(questionArea);
		
		op1=new JLabel("Option 1 : ");
        f.add(op1);
		op1.setBounds(50,110,130,35);
       f.add(option1Area);
		
		op2=new JLabel("Option 2 : ");
        f.add(op2);
		op2.setBounds(50,150,130,35);
        f.add(option2Area);
		
		op3=new JLabel("Option 3 : ");
        f.add(op3);
		op3.setBounds(50,190,130,35);
        f.add(option3Area);
		
		op4=new JLabel("Option 4 : ");
       f.add(op4);
		op4.setBounds(50,230,130,35);
        f.add(option4Area);
		
		carind=new JLabel("Correct Option : ");
        f.add(carind);
		carind.setBounds(50,270,130,35);
       f.add(correctIndexField);
		
		smslab=new JLabel("First fill the boxes then press add or edit or delete or save ! thanks ");
		f.add(smslab);
		smslab.setBounds(50,400,700,35);
		
        f.add(addButton);
       f.add(editButton);
        f.add(deleteButton);
       f.add(saveButton);
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
	
	  f.setSize(1000,650);
	  f.setLayout(null);
      
        f.setVisible(true);
		  f.setLocationRelativeTo(null);
		
		//f.getContentPane().setBackground(new Color(153,153,153));
		f.getContentPane().setBackground(new Color(255,255,204));
    }

    
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addButton) {
            addQuestion();
        } else if (e.getSource() == editButton) {
            editQuestion();
        } else if (e.getSource() == deleteButton) {
            deleteQuestion();
        } else if (e.getSource() == saveButton) {
            saveQuestions();
        }
		else if (e.getSource() == bb) {
			f.setVisible(false);
            new AdminQuizs();
           }
	} 

    

    private void addQuestion() {
		
        String questionNumber = questionNumberField.getText();
        String question = questionArea.getText();
        String option1 = option1Area.getText();
        String option2 = option2Area.getText();
        String option3 = option3Area.getText();
        String option4 = option4Area.getText();
		
		String correctOption = correctIndexField.getText();
		
		
		
        //String correctIndex = correctIndexField.getText();
       
      
        if (questionNumber.isEmpty() || question.isEmpty() || option1.isEmpty() || 
        option2.isEmpty() || option3.isEmpty() || option4.isEmpty() || correctOption.isEmpty()) {
              JOptionPane.showMessageDialog(f, "Please fill all fields!");
              return;
          }
          int Value = Integer.parseInt(correctOption);
          int realValue = (Value - 1) ;
          
          String correctIndex = (realValue + "");
          String[] newQuestion = {questionNumber, question, option1, option2, option3, option4, correctIndex};
         

        try {
            

			  if (isqsnExists(questionNumber)) {
                JOptionPane.showMessageDialog(f, "question already exists!");
                clearFields(); // Clear all fields
                return;
            }
			
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));
            writer.write(String.join(",", newQuestion));
            writer.newLine();
            writer.close();
			 ImageIcon icon1 = new ImageIcon("rightsign.png");
		
            JOptionPane.showMessageDialog(null,"Question added successfully."," ",JOptionPane.PLAIN_MESSAGE,icon1);
			clearFields(); 
        } catch (IOException ex) {
            ex.printStackTrace();
            
            JOptionPane.showMessageDialog(this, "Failed to add question.");
        }
    }

private boolean isqsnExists( String questionNumber) {
        try {
            File file = new File(fileName);
            if (!file.exists()) {
                return false;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length== 7 && parts[0].equals(questionNumber)) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
    }
    private void clearFields() {
         questionNumberField.setText("");
         questionArea.setText("");
         option1Area.setText("");
		 option2Area.setText("");
		 option3Area.setText("");
		 option4Area.setText("");
        correctIndexField.setText("");
       
    }
  private void editQuestion() {
    String questionNumber = questionNumberField.getText();
    String question = questionArea.getText();
    String option1 = option1Area.getText();
    String option2 = option2Area.getText();
    String option3 = option3Area.getText();
    String option4 = option4Area.getText();
	
   String correctOption = correctIndexField.getText();
		
	

   if (questionNumber.isEmpty() || question.isEmpty() || option1.isEmpty() || 
	        option2.isEmpty() || option3.isEmpty() || option4.isEmpty() || correctOption.isEmpty()) {
            JOptionPane.showMessageDialog(f, "Please fill all fields!");
            return;
        }
		
		if(isqsnExists(questionNumber)){

            int Value = Integer.parseInt(correctOption);
            int realValue = (Value - 1) ;
            
            String correctIndex = realValue + "";
    
    String[] editedQuestion = {questionNumber, question, option1, option2, option3, option4, correctIndex};
  
    try {
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        StringBuilder fileContent = new StringBuilder();
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length == 7 && parts[0].equals(questionNumber)) {
                line = String.join(",", editedQuestion);
            }
            fileContent.append(line).append("\n");
        }
        reader.close();

        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
        writer.write(fileContent.toString());
        writer.close();
        JOptionPane.showMessageDialog(this, "Question edited successfully.");
		clearFields();
    } catch (IOException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, "Failed to edit question.");
		clearFields(); 
    }
		}
		else {
			JOptionPane.showMessageDialog(this, "No question found enter the correct qs. no.");
		}
}

 private void deleteQuestion() {
	 
	 
    String questionNumber = questionNumberField.getText();

      if (questionNumber.isEmpty() ) {
            JOptionPane.showMessageDialog(f, "Please enter the question number!");
            return;
        }
		 if (!isqsnExists(questionNumber)) {
        JOptionPane.showMessageDialog(f, "Question does not exist!");
        clearFields();
        return;
    }
    try {
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        StringBuilder fileContent = new StringBuilder();
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length == 7 && !parts[0].equals(questionNumber)) {
                fileContent.append(line).append("\n");
            }
        }
        reader.close();

        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
        writer.write(fileContent.toString());
        writer.close();
        JOptionPane.showMessageDialog(this, "Question deleted successfully.");
		clearFields();
    } catch (IOException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, "Failed to delete question.");
    }
}

   private void saveQuestions() 
   {
   int pulock = JOptionPane.showConfirmDialog(null, "Are you sure ?", "save", JOptionPane.YES_NO_OPTION);
                if (pulock == JOptionPane.YES_OPTION) {
                    f.setVisible(false);
	                new  AdminQuizs();
				}
				if (pulock == JOptionPane.NO_OPTION) {
                    
				}
				
   }
    /*public static void main(String[] args) 
	{
        new AdminPanel();
    }*/
   
}
