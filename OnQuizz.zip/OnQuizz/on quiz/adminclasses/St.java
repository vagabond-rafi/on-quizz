package adminclasses;
import java.util.Scanner;


public class St{

    
  public static void main(String[] args) {
    CourseList courseList = new CourseList(100);
	AdminPage adminPage = new AdminPage(courseList); // Initialize Admin Panel
	

    CoursesFileIO.loadCoursesFromFile(courseList);
    InventoryPage sp = new InventoryPage(courseList);
  }
}

