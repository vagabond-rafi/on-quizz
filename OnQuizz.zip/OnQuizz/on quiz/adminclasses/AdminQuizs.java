package adminclasses;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import userclasses.*;
//import textfiles.*;
//import pictures.*;
public class AdminQuizs extends JFrame implements ActionListener {
    JButton quiz2Button,quiz1Button,bb;
	JLabel cimagelab,javaimagelab;
	 JFrame f;
	
	 public AdminQuizs() {
        setTitle("Ongoing quizes");
      
       f=new JFrame("Edit Ongoing quizes");
      

        quiz1Button = new JButton("Quiz 1 on c++ ");
        quiz2Button = new JButton("Quiz 2 on JAVA ");
         bb = new JButton("Back");
		 cimagelab = new JLabel();
		  javaimagelab = new JLabel();
		 
        quiz1Button.setBounds(50,50,225,125);
		quiz2Button.setBounds(200,230,225,125);
		bb.setBounds(10,460,100,35);
		
         quiz1Button.addActionListener(this);
         quiz2Button.addActionListener(this);
		 bb.addActionListener(this);
		  f.add(quiz1Button);
          f.add(quiz2Button);
          f.add(bb);
		  
		f.add(cimagelab);
        f.add(javaimagelab);
		
		
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
	
	  f.setSize(500,550);
	  f.setLayout(null);
      
        f.setVisible(true);
		  f.setLocationRelativeTo(null);
		  
		  
		//ImageIcon img = new ImageIcon("c++pic.png");
		ImageIcon img = new ImageIcon("C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\pictures\\c++pic.png");
		cimagelab.setIcon(img);
		cimagelab.setBounds(320,70,150,75);
		
		  
		// icon = new ImageIcon("javapic.png");
		ImageIcon icon = new ImageIcon("C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\pictures\\javapic.png");
		javaimagelab.setIcon(icon);
		javaimagelab.setBounds(10,250,150,75);
        
	
	 }
	//String qs1fileName = "questions.txt";
	
	public void actionPerformed(ActionEvent e) {
        if (e.getSource() == quiz1Button) {
           f.setVisible(false);
		new ManageQuestion("questions.txt");
			
        } else if (e.getSource() == quiz2Button) {
            f.setVisible(false);

	     new ManageQuestion("quiz2questions.txt");
		 //new ManageQuestion("C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\textfiles\\quiz2questions.txt");
			
        }
		else if (e.getSource() == bb) {
           f.setVisible(false); 
	    new AdminDashboard();
			
        }
		
		
		
    }
	
	
	
	
	
	
	
	
}