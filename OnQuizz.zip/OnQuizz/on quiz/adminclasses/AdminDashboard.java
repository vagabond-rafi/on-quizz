package adminclasses;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import userclasses.*;
//import textfiles.*;
//import pictures.*;

public class AdminDashboard implements ActionListener {
    private JFrame frame;

    public AdminDashboard() {
        frame = new JFrame("Admin Dashboard");


        JLabel titleLabel = new JLabel("Admin Dashboard");
        titleLabel.setBounds(400, 20, 200, 30);
        frame.add(titleLabel);
        
		Font f = new Font("Arial",Font.BOLD,20);
        titleLabel.setFont(f);




        JButton manageUsersButton = new JButton("Manage Users");
        manageUsersButton.setBounds(400, 160, 200, 50);
        manageUsersButton.addActionListener(this);
        frame.add(manageUsersButton);
        //manageUsersButton.setFont(f);


        JButton manageOnQuiz = new JButton("Manage Ongoing Quizes");
         manageOnQuiz.setBounds(400, 80, 200, 50);
         manageOnQuiz.addActionListener(this);
        frame.add(manageOnQuiz);
          


 JButton manageUpQuiz = new JButton("Manage Upcoming Quizes");
         manageUpQuiz.setBounds(700, 80, 200, 50);
         manageUpQuiz.addActionListener(this);
        frame.add(manageUpQuiz);

        JButton managecourse = new JButton("Manage Courses");
        managecourse.setBounds(700, 160, 200, 50);
        managecourse.addActionListener(this);
       frame.add(managecourse);




          //manageUpQuiz.setFont(f);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(800, 500, 100, 30);
        
        logoutButton.addActionListener(this);
        frame.add(logoutButton);
		
		 JButton bb = new JButton("Back");
        bb.setBounds(400, 500, 100, 30);
        bb.addActionListener(this);
        frame.add(bb);
         
		 JLabel imlabel = new JLabel();
       // ImageIcon img = new ImageIcon("adminpic1.png");
       ImageIcon img = new ImageIcon( "C:\\Users\\USER\\OneDrive\\Desktop\\on quiz\\pictures\\adminpic1.png");
		imlabel.setIcon(img);
		imlabel.setBounds(50,50,510,510);
        frame.add(imlabel);

        frame.setSize(1000, 650);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
		frame.setResizable(false);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton button = (JButton) e.getSource();
            if (button.getText().equals("Manage Users")) {
                frame.dispose(); // Close Admin Dashboard
				new ManageUsers();
            } else if (button.getText().equals("Manage Ongoing Quizes")) {
				
                frame.dispose(); // Close Admin Dashboard
				new AdminQuizs();
				
            } else if (button.getText().equals("Logout")) {
                frame.dispose();
                new Login();
            }
			else if (button.getText().equals("Back")) {
                frame.dispose();
                new Login();
            }else if (button.getText().equals("Manage Upcoming Quizes")) {
                frame.dispose();
                new AddQuiz();
            }
            else if (button.getText().equals("Manage Courses")) {
                frame.dispose();
                St stInstance = new St();
               
                 String[] args = {}; // Pass any necessary arguments to the main method
                 stInstance.main(args);
            }
        }
    }
	
	/*public static void main(String[] args)
    {
		new AdminDashboard();
	}*/
	
}
