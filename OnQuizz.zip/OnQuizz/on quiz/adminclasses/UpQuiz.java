package adminclasses;
import java.io.Serializable;

public class UpQuiz implements Serializable {
    private String name;
    private String code;
   
    

    public UpQuiz(String name, String code) {
        this.name = name;
        this.code = code;
              
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setCode(String code) {
        this.code = code;
    }
    public String getCode() {
        return code;
    }



    
    @Override
    public String toString() {
        return "Name: " + name +
                "\nCode: " + code ;
                             
}
}

