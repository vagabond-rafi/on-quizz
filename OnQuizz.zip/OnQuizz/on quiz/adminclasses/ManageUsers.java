package adminclasses;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import userclasses.*;

//import textfiles.*;
//import pictures.*;

public class ManageUsers implements ActionListener {
    private JFrame frame;

    public ManageUsers() {
        frame = new JFrame("Manage Users");
        frame.setSize(600, 600);
        frame.setLayout(null);

        JLabel titleLabel = new JLabel("Manage Users");
        titleLabel.setBounds(220, 20, 200, 30);
        frame.add(titleLabel);

        JButton displayUsersButton = new JButton("ALL Users");
        displayUsersButton.setBounds(50, 80, 200, 30);
        displayUsersButton.addActionListener(this);
        frame.add(displayUsersButton);

        JButton addUserButton = new JButton("Add User");
        addUserButton.setBounds(50, 130, 200, 30);
        addUserButton.addActionListener(this);
        frame.add(addUserButton);

        JButton updateUserButton = new JButton("Update User Info");
        updateUserButton.setBounds(350, 80, 200, 30);
        updateUserButton.addActionListener(this);
        frame.add(updateUserButton);

        JButton searchUserButton = new JButton("Search User");
        searchUserButton.setBounds(350, 130, 200, 30);
        searchUserButton.addActionListener(this);
        frame.add(searchUserButton);

        JButton deleteUserButton = new JButton("Delete User");
        deleteUserButton.setBounds(200, 180, 200, 30);
        deleteUserButton.addActionListener(this);
        frame.add(deleteUserButton);
        
        JButton backButton = new JButton("Back");
        backButton.setBounds(50, 500, 100, 30);
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new AdminDashboard();
            }
        });
        frame.add(backButton);
        
        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(450, 500, 80, 30);
        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new Login();
            }
        });
        frame.add(logoutButton);

        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            JButton button = (JButton) e.getSource();
            if (button.getText().equals("ALL Users")) {
                displayUsers();
            } else if (button.getText().equals("Add User")) {
                frame.dispose();
				new AddUser(new ManageUsers());
            } else if (button.getText().equals("Update User Info")) {
				frame.dispose();
                new UpdateUser();
            } 
else if (button.getText().equals("Search User")) {
                searchUser();
            } else if (button.getText().equals("Delete User")) {
                deleteUser();
            }
        }
    }

    public void displayUsers() {
		
		
        try {
            File file = new File("userdata.txt");
            if (!file.exists()) {
                JOptionPane.showMessageDialog(frame, "No users registered yet!");
                return;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            StringBuilder usersInfo = new StringBuilder();
            int numUsers = countLines(file);
            String[] usersData = new String[numUsers];
            int index = 0;
            while ((line = reader.readLine()) != null) {
                usersData[index++] = line;
                String[] parts = line.split(",");
                String userInfo = String.format("Name: %s, Email: %s, Gender: %s\n", parts[0], parts[1], parts[3]);
                usersInfo.append(userInfo);
            }
            reader.close();

            JTextArea textArea = new JTextArea(usersInfo.toString());
            textArea.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(400, 300));
            JOptionPane.showMessageDialog(frame, scrollPane, "Registered Users", JOptionPane.PLAIN_MESSAGE);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

   /* private void updateUserInfo() {
        String email = JOptionPane.showInputDialog(frame, "Enter email of the user to update:");
        if (email == null || email.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Email cannot be empty!");
            return;
        }
		
		frame.dispose();
		new UpdateUser();
    */

    private void searchUser() {
        String email = JOptionPane.showInputDialog(frame, "Enter email of the user to search:");
        if (email == null || email.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Email cannot be empty!");
            return;
        }

        try {
            File file = new File("userdata.txt");
            if (!file.exists()) {
                JOptionPane.showMessageDialog(frame, "No users registered yet!");
                return;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            StringBuilder userInfo = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[1].equals(email)) {
                    userInfo.append(String.format("Name: %s, Email: %s, Gender: %s\n", parts[0], parts[1], parts[3]));
                    break;
                }
            }
            reader.close();

            if (userInfo.length() > 0) {
                JOptionPane.showMessageDialog(frame, userInfo.toString(), "User Details", JOptionPane.PLAIN_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "User not found!");
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void deleteUser() {
		
		 String email = JOptionPane.showInputDialog(frame, "Enter email of the user to delete:");
        if (email == null || email.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Email cannot be empty!");
            return;
        }
		
                if (isEmailExists(email)) {
        String[][] lines = null;
        try {
            File file = new File("userdata.txt");
            if (!file.exists()) {
                JOptionPane.showMessageDialog(frame, "No users registered yet!");
                return;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            int numUsers = countLines(file);
            lines = new String[numUsers][];
            int count = 0;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (!parts[1].equals(email)) {
                    lines[count++] = parts;
                }
            }
            reader.close();

            FileWriter writer = new FileWriter(file);
            for (int i = 0; i < count; i++) {
                writer.write(String.join(",", lines[i]) + "\n");
            }
            writer.close();

            JOptionPane.showMessageDialog(frame, "User deleted successfully!");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
				}
		
		else {
			
			JOptionPane.showMessageDialog(frame, "User not exist please try with another em!");
		}
				
				
				
				
				
    }
private boolean isEmailExists( String email) {
        try {
            File file = new File("userdata.txt");
            if (!file.exists()) {
                return false;
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length== 4 && parts[1].equals(email)) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return false;
    }
    private int countLines(File file) throws IOException {
        int lines = 0;
        BufferedReader reader = new BufferedReader(new FileReader(file));
        while (reader.readLine() != null) lines++;
        reader.close();
        return lines;
    }
	
	/*public static void main(String[] args)
    {
		new ManageUsers();
	}*/
	
}
